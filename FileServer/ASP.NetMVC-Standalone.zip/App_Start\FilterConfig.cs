﻿using System.Web;
using System.Web.Mvc;

namespace aspnet_get_started
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
